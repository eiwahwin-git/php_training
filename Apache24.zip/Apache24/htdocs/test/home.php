<?php phpinfo();
$servername = "localhost";
$username = "root";
$password = "root";
$database ="colors";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
console.log($conn);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
  // echo "UnsuccessfullY!;
}
echo "Connected successfully";

?>