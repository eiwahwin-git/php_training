<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Tutorial 01</title>
</head>

<body style="text-align: center;">
  <h3>Chess Board</h3>
    <?php
    include("tutorial_01.php");
    ?>
</body>

</html>