<table style="margin: auto; border: 2px solid black; border-spacing: 0;">
  <?php
  for ($row = 1; $row <= 8; $row++) {
    echo "<tr>";
    for ($col = 1; $col <= 8; $col++) {
      $total = $row + $col;
      if ($total % 2 == 0) {
        echo "<td height=60px width=60px bgcolor=#FFFFFF></td>";
      } else {
        echo "<td height=60px width=60px bgcolor=#000000></td>";
      }
    }
    echo "</tr>";
  }
  ?>
</table>